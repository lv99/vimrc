// JavaScript goodness

// Files and directory structures
	var cssDir = "./Stylesheets/";
	var NS4CSS = "wango.css";

